const express = require('express');
const router = express.Router();

const userController = require('../modules/users/userController');
const authMiddleware = require('../middlewares/authMiddleware');

router.post('/register', userController.registerUser);
router.post('/login', userController.loginUser);
router.post('/refresh', userController.refreshTokens);
router.get('/me', authMiddleware, userController.getMe);
router.get('/:userId', userController.getUserById);
router.get('/', userController.listUsers);

module.exports = router;
